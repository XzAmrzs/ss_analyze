#!/usr/bin/env python
# encoding: utf-8
# Author:  Xzp
# Date: 2016/8/25 0025 上午 9:08

import json
import time
import re

from kafka import KafkaConsumer, TopicPartition
from pymongo import MongoClient
from kazoo.client import KazooClient
from kazoo.exceptions import KazooException

from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils, TopicAndPartition

# 添加项目依赖环境
import sys

sys.path.append('/home/xzp/ss_analyze/utils/')

import tools

database_name = 'hls'
database_driver_host = 'localhost'
database_driver_port = 27017

logPath = ''
timeYmd = tools.timeFormat('%Y%m%d', int(time.time()))
app_name = 'hdfs_test'


def nodeHls_valid_filter(s):
    return (s[0] == 'nodeHlsTest') and (('.m3u8' in s[1]) or ('.ts' in s[1]))


def json2dict(s):
    """
    :param s: str
    :return: dict
    """
    try:
        dit = json.loads(s, encoding='utf-8')
        return dit
    except Exception as e:
        tools.logout(logPath, app_name, timeYmd, 'Error Load Json: ' + s[1] + ' ' + str(e), 3)
        return {}


def hlsParser(body_dict):
    """
    获取hls用户数据的函数
    :param body_dict: dict
    :return: type:((user,timestamp.app,stream), flux) -> (('1234',"1470898486","1529","stream"), 448))
    """
    # 获取APP和stream
    request_url = body_dict.get('request_url', 'error_request_url')
    # 这里不能用简单的'/'来分割,会碰到请求的url有多个'/'的情况
    # GET http://hzsrzj/hzsrzj-stream-1470988831-1470991945170-3042.ts HTTP/1.1
    # 所以解析的时候直接全转成空格，然后按照任意长度的空格来分割
    request_url_list = request_url.replace('/', ' ')
    app_stream = re.split(' *', request_url_list)
    try:
        app = app_stream[1]
        if '.m3u8' in request_url:
            # 'GET /szqhqh/stream.m3u8 HTTP/1.1'
            stream = app_stream[2].split('.')[0]
        else:
            if 'http' in request_url:
                app = app_stream[-4]
                stream = app_stream[-3].split('-')[1]
            else:
                # 'GET /1529/1529-stream-1459483582-1459486842823-3041.ts HTTP/1.1'
                stream = app_stream[2].split('-')[1]
    except Exception as e:
        tools.logout(logPath, app_name, timeYmd, 'Error: ' + request_url + str(app_stream) + str(e), 1)
        app = 'error'
        stream = 'error'
    # 因为有的是上行数据，没有user这个字段，所以统一归为'no user keyword'字段

    user = body_dict.get('user', "no user keyword")
    flux = body_dict.get('body_bytes_sent', 0)
    timestamp = tools.timeFormat('%Y%m%d', float(body_dict.get('unix_time', 0)))
    data = (user, timestamp, app, stream), flux
    return data


def rtmpParser(body_dict):
    """
    :param body_dict: dict
    :return: type:((user,timestamp.app,stream), flux) -> (('1234',"1470898486","1529","stream"), 448))
    """
    user = body_dict.get('User', "no user keyword")
    timestamp = tools.timeFormat('%Y%m%d', float(body_dict.get('EndTime', 0)))
    app = body_dict.get('App', 'no App keyword')
    stream = body_dict.get('Stream', 'no Stream keyword')
    cmd = body_dict.get('Cmd', '')
    flux = 0
    try:
        if cmd == 'play':
            flux = body_dict.get('SendByteSum', 0)
        else:
            flux = body_dict.get('RecvByteSum', 0)
    except Exception as e:
        tools.logout(logPath, app_name, timeYmd, 'Error: rtmpParser' + str(e), 1)
    # 因为有的是上行数据，没有user这个字段，所以统一归为'no user keyword'字段
    data = (user, timestamp, app, stream, cmd), flux
    return data


def store_data(iter, flag, col_names):
    """
    :param iter: abc
    :param col_names: list
    :return: None

    官方文档提示采用lazy模式的连接池来进行数据的入库操作 参考 : http://shiyanjun.cn/archives/1097.html
    关键点: 实现数据库的(序列化)和(反序列化)接口，或者也可以避免,理想效果是只传入sql语句即可??
    """

    try:
        client = MongoClient(database_driver_host, database_driver_port)
        db = client.get_database(database_name)
        dao_store_and_update(db, flag, col_names, iter)
        client.close()
    except Exception as e:
        tools.logout(logPath, app_name, timeYmd, 'Error: ' + str(e), 1)


def dao_store_and_update(db, flag, col_names, iter):
    for record in iter:
        if flag == 'nodeHls':
            user, timestamp, app, stream = record[0]
            data = {"timestamp": timestamp}
        else:
            user, timestamp, app, stream, cmd = record[0]
            data = {"timestamp": timestamp, "cmd": cmd}
        flux = record[1]

        for index, col_name in enumerate(col_names):
            col = db.get_collection(col_name)

            if index != 1 and user == 'no user keyword':
                # 如果是上行数据,那么只更新user_flux表
                continue
            if index == 1:
                data['user'] = user
            if index == 2:
                data['app'] = app
            if index == 3:
                data['stream'] = stream
            update_dit = {'$inc': {'flux': flux}}
            col.update(data, update_dit, True)


if __name__ == '__main__':
    sc = SparkContext(appName=app_name)

    sc.addPyFile('./utils/tools.py')

    ssc = StreamingContext(sc, 15)
    streams = ssc.textFileStream("/data/data/hls/")

    # ################### nodeHls数据处理 #############################
    nodeHls_body_dict = streams.filter(nodeHls_valid_filter).map(
        json2dict).filter(lambda d: (d.get('http_stat', 0) < 400 and d.get('http_stat', 0) != 202))
    # user_time_app_stream_flux
    nodeHls_utasf_counts = nodeHls_body_dict.map(hlsParser).reduceByKey(lambda x, y: x + y)
    nodeHls_utasf_counts.foreachRDD(
        lambda rdd: rdd.foreachPartition(lambda x: store_data(x, 'nodeHls', col_names=(
            'hls_timestamp_flux', 'hls_user_flux', 'hls_user_app_flux', 'hls_user_app_stream_flux'))))

    ssc.start()
    ssc.awaitTermination()
